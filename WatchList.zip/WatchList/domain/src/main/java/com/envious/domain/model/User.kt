package com.envious.domain.model

data class User(
    val userName: String,
    val password: String
)
