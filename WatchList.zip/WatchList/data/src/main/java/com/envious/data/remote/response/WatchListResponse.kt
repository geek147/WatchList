package com.envious.data.remote.response

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
data class WatchListResponse(
    @SerializedName("Data")
    val `data`: List<Data?>? = null,
    @SerializedName("HasWarning")
    val hasWarning: Boolean? = null,
    @SerializedName("Message")
    val message: String? = null,
    @SerializedName("MetaData")
    val metaData: MetaData? = null,
    @SerializedName("RateLimit")
    val rateLimit: RateLimit? = null,
    @SerializedName("SponsoredData")
    val sponsoredData: List<SponsoredData?>? = null,
    @SerializedName("Type")
    val type: Int? = null
) {
    @Keep
    data class Data(
        @SerializedName("CoinInfo")
        val coinInfo: CoinInfo? = null,
        @SerializedName("DISPLAY")
        val dISPLAY: DISPLAY? = null,
        @SerializedName("RAW")
        val rAW: RAW? = null
    ) {
        @Keep
        data class CoinInfo(
            @SerializedName("Algorithm")
            val algorithm: String? = null,
            @SerializedName("AssetLaunchDate")
            val assetLaunchDate: String? = null,
            @SerializedName("BlockNumber")
            val blockNumber: Int? = null,
            @SerializedName("BlockReward")
            val blockReward: Double? = null,
            @SerializedName("BlockTime")
            val blockTime: Int? = null,
            @SerializedName("DocumentType")
            val documentType: String? = null,
            @SerializedName("FullName")
            val fullName: String? = null,
            @SerializedName("Id")
            val id: String? = null,
            @SerializedName("ImageUrl")
            val imageUrl: String? = null,
            @SerializedName("Internal")
            val `internal`: String? = null,
            @SerializedName("MaxSupply")
            val maxSupply: Double? = null,
            @SerializedName("Name")
            val name: String? = null,
            @SerializedName("NetHashesPerSecond")
            val netHashesPerSecond: Long? = null,
            @SerializedName("ProofType")
            val proofType: String? = null,
            @SerializedName("Rating")
            val rating: Rating? = null,
            @SerializedName("Type")
            val type: Int? = null,
            @SerializedName("Url")
            val url: String? = null
        ) {
            @Keep
            data class Rating(
                @SerializedName("Weiss")
                val weiss: Weiss? = null
            ) {
                @Keep
                data class Weiss(
                    @SerializedName("MarketPerformanceRating")
                    val marketPerformanceRating: String? = null,
                    @SerializedName("Rating")
                    val rating: String? = null,
                    @SerializedName("TechnologyAdoptionRating")
                    val technologyAdoptionRating: String? = null
                )
            }
        }

        @Keep
        data class DISPLAY(
            @SerializedName("USD")
            val uSD: USD? = null
        ) {
            @Keep
            data class USD(
                @SerializedName("CHANGE24HOUR")
                val cHANGE24HOUR: String? = null,
                @SerializedName("CHANGEDAY")
                val cHANGEDAY: String? = null,
                @SerializedName("CHANGEHOUR")
                val cHANGEHOUR: String? = null,
                @SerializedName("CHANGEPCT24HOUR")
                val cHANGEPCT24HOUR: String? = null,
                @SerializedName("CHANGEPCTDAY")
                val cHANGEPCTDAY: String? = null,
                @SerializedName("CHANGEPCTHOUR")
                val cHANGEPCTHOUR: String? = null,
                @SerializedName("CIRCULATINGSUPPLY")
                val cIRCULATINGSUPPLY: String? = null,
                @SerializedName("CIRCULATINGSUPPLYMKTCAP")
                val cIRCULATINGSUPPLYMKTCAP: String? = null,
                @SerializedName("CONVERSIONSYMBOL")
                val cONVERSIONSYMBOL: String? = null,
                @SerializedName("CONVERSIONTYPE")
                val cONVERSIONTYPE: String? = null,
                @SerializedName("FROMSYMBOL")
                val fROMSYMBOL: String? = null,
                @SerializedName("HIGH24HOUR")
                val hIGH24HOUR: String? = null,
                @SerializedName("HIGHDAY")
                val hIGHDAY: String? = null,
                @SerializedName("HIGHHOUR")
                val hIGHHOUR: String? = null,
                @SerializedName("IMAGEURL")
                val iMAGEURL: String? = null,
                @SerializedName("LASTMARKET")
                val lASTMARKET: String? = null,
                @SerializedName("LASTTRADEID")
                val lASTTRADEID: String? = null,
                @SerializedName("LASTUPDATE")
                val lASTUPDATE: String? = null,
                @SerializedName("LASTVOLUME")
                val lASTVOLUME: String? = null,
                @SerializedName("LASTVOLUMETO")
                val lASTVOLUMETO: String? = null,
                @SerializedName("LOW24HOUR")
                val lOW24HOUR: String? = null,
                @SerializedName("LOWDAY")
                val lOWDAY: String? = null,
                @SerializedName("LOWHOUR")
                val lOWHOUR: String? = null,
                @SerializedName("MARKET")
                val mARKET: String? = null,
                @SerializedName("MKTCAP")
                val mKTCAP: String? = null,
                @SerializedName("MKTCAPPENALTY")
                val mKTCAPPENALTY: String? = null,
                @SerializedName("OPEN24HOUR")
                val oPEN24HOUR: String? = null,
                @SerializedName("OPENDAY")
                val oPENDAY: String? = null,
                @SerializedName("OPENHOUR")
                val oPENHOUR: String? = null,
                @SerializedName("PRICE")
                val pRICE: String? = null,
                @SerializedName("SUPPLY")
                val sUPPLY: String? = null,
                @SerializedName("TOPTIERVOLUME24HOUR")
                val tOPTIERVOLUME24HOUR: String? = null,
                @SerializedName("TOPTIERVOLUME24HOURTO")
                val tOPTIERVOLUME24HOURTO: String? = null,
                @SerializedName("TOSYMBOL")
                val tOSYMBOL: String? = null,
                @SerializedName("TOTALTOPTIERVOLUME24H")
                val tOTALTOPTIERVOLUME24H: String? = null,
                @SerializedName("TOTALTOPTIERVOLUME24HTO")
                val tOTALTOPTIERVOLUME24HTO: String? = null,
                @SerializedName("TOTALVOLUME24H")
                val tOTALVOLUME24H: String? = null,
                @SerializedName("TOTALVOLUME24HTO")
                val tOTALVOLUME24HTO: String? = null,
                @SerializedName("VOLUME24HOUR")
                val vOLUME24HOUR: String? = null,
                @SerializedName("VOLUME24HOURTO")
                val vOLUME24HOURTO: String? = null,
                @SerializedName("VOLUMEDAY")
                val vOLUMEDAY: String? = null,
                @SerializedName("VOLUMEDAYTO")
                val vOLUMEDAYTO: String? = null,
                @SerializedName("VOLUMEHOUR")
                val vOLUMEHOUR: String? = null,
                @SerializedName("VOLUMEHOURTO")
                val vOLUMEHOURTO: String? = null
            )
        }

        @Keep
        data class RAW(
            @SerializedName("USD")
            val uSD: USD? = null
        ) {
            @Keep
            data class USD(
                @SerializedName("CHANGE24HOUR")
                val cHANGE24HOUR: Double? = null,
                @SerializedName("CHANGEDAY")
                val cHANGEDAY: Double? = null,
                @SerializedName("CHANGEHOUR")
                val cHANGEHOUR: Double? = null,
                @SerializedName("CHANGEPCT24HOUR")
                val cHANGEPCT24HOUR: Double? = null,
                @SerializedName("CHANGEPCTDAY")
                val cHANGEPCTDAY: Double? = null,
                @SerializedName("CHANGEPCTHOUR")
                val cHANGEPCTHOUR: Double? = null,
                @SerializedName("CIRCULATINGSUPPLY")
                val cIRCULATINGSUPPLY: Int? = null,
                @SerializedName("CIRCULATINGSUPPLYMKTCAP")
                val cIRCULATINGSUPPLYMKTCAP: Double? = null,
                @SerializedName("CONVERSIONSYMBOL")
                val cONVERSIONSYMBOL: String? = null,
                @SerializedName("CONVERSIONTYPE")
                val cONVERSIONTYPE: String? = null,
                @SerializedName("FLAGS")
                val fLAGS: String? = null,
                @SerializedName("FROMSYMBOL")
                val fROMSYMBOL: String? = null,
                @SerializedName("HIGH24HOUR")
                val hIGH24HOUR: Double? = null,
                @SerializedName("HIGHDAY")
                val hIGHDAY: Double? = null,
                @SerializedName("HIGHHOUR")
                val hIGHHOUR: Double? = null,
                @SerializedName("IMAGEURL")
                val iMAGEURL: String? = null,
                @SerializedName("LASTMARKET")
                val lASTMARKET: String? = null,
                @SerializedName("LASTTRADEID")
                val lASTTRADEID: String? = null,
                @SerializedName("LASTUPDATE")
                val lASTUPDATE: Int? = null,
                @SerializedName("LASTVOLUME")
                val lASTVOLUME: Double? = null,
                @SerializedName("LASTVOLUMETO")
                val lASTVOLUMETO: Double? = null,
                @SerializedName("LOW24HOUR")
                val lOW24HOUR: Double? = null,
                @SerializedName("LOWDAY")
                val lOWDAY: Double? = null,
                @SerializedName("LOWHOUR")
                val lOWHOUR: Double? = null,
                @SerializedName("MARKET")
                val mARKET: String? = null,
                @SerializedName("MEDIAN")
                val mEDIAN: Double? = null,
                @SerializedName("MKTCAP")
                val mKTCAP: Double? = null,
                @SerializedName("MKTCAPPENALTY")
                val mKTCAPPENALTY: Int? = null,
                @SerializedName("OPEN24HOUR")
                val oPEN24HOUR: Double? = null,
                @SerializedName("OPENDAY")
                val oPENDAY: Double? = null,
                @SerializedName("OPENHOUR")
                val oPENHOUR: Double? = null,
                @SerializedName("PRICE")
                val pRICE: Double? = null,
                @SerializedName("SUPPLY")
                val sUPPLY: Int? = null,
                @SerializedName("TOPTIERVOLUME24HOUR")
                val tOPTIERVOLUME24HOUR: Double? = null,
                @SerializedName("TOPTIERVOLUME24HOURTO")
                val tOPTIERVOLUME24HOURTO: Double? = null,
                @SerializedName("TOSYMBOL")
                val tOSYMBOL: String? = null,
                @SerializedName("TOTALTOPTIERVOLUME24H")
                val tOTALTOPTIERVOLUME24H: Double? = null,
                @SerializedName("TOTALTOPTIERVOLUME24HTO")
                val tOTALTOPTIERVOLUME24HTO: Double? = null,
                @SerializedName("TOTALVOLUME24H")
                val tOTALVOLUME24H: Double? = null,
                @SerializedName("TOTALVOLUME24HTO")
                val tOTALVOLUME24HTO: Double? = null,
                @SerializedName("TYPE")
                val tYPE: String? = null,
                @SerializedName("VOLUME24HOUR")
                val vOLUME24HOUR: Double? = null,
                @SerializedName("VOLUME24HOURTO")
                val vOLUME24HOURTO: Double? = null,
                @SerializedName("VOLUMEDAY")
                val vOLUMEDAY: Double? = null,
                @SerializedName("VOLUMEDAYTO")
                val vOLUMEDAYTO: Double? = null,
                @SerializedName("VOLUMEHOUR")
                val vOLUMEHOUR: Double? = null,
                @SerializedName("VOLUMEHOURTO")
                val vOLUMEHOURTO: Double? = null
            )
        }
    }

    @Keep
    data class MetaData(
        @SerializedName("Count")
        val count: Int? = null
    )

    @Keep
    class RateLimit

    @Keep
    data class SponsoredData(
        @SerializedName("CoinInfo")
        val coinInfo: CoinInfo? = null
    ) {
        @Keep
        data class CoinInfo(
            @SerializedName("Algorithm")
            val algorithm: String? = null,
            @SerializedName("AssetLaunchDate")
            val assetLaunchDate: String? = null,
            @SerializedName("BlockNumber")
            val blockNumber: Int? = null,
            @SerializedName("BlockReward")
            val blockReward: Int? = null,
            @SerializedName("BlockTime")
            val blockTime: Int? = null,
            @SerializedName("DocumentType")
            val documentType: String? = null,
            @SerializedName("FullName")
            val fullName: String? = null,
            @SerializedName("Id")
            val id: String? = null,
            @SerializedName("ImageUrl")
            val imageUrl: String? = null,
            @SerializedName("Internal")
            val `internal`: String? = null,
            @SerializedName("MaxSupply")
            val maxSupply: Int? = null,
            @SerializedName("Name")
            val name: String? = null,
            @SerializedName("NetHashesPerSecond")
            val netHashesPerSecond: Int? = null,
            @SerializedName("ProofType")
            val proofType: String? = null,
            @SerializedName("Rating")
            val rating: Rating? = null,
            @SerializedName("Type")
            val type: Int? = null,
            @SerializedName("Url")
            val url: String? = null
        ) {
            @Keep
            data class Rating(
                @SerializedName("Weiss")
                val weiss: Weiss? = null
            ) {
                @Keep
                data class Weiss(
                    @SerializedName("MarketPerformanceRating")
                    val marketPerformanceRating: String? = null,
                    @SerializedName("Rating")
                    val rating: String? = null,
                    @SerializedName("TechnologyAdoptionRating")
                    val technologyAdoptionRating: String? = null
                )
            }
        }
    }
}